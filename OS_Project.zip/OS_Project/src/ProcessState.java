public enum ProcessState {
    Running, NotRunning;
}
