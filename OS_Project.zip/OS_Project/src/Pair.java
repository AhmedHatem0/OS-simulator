public class Pair {
    String x;
    String y;

    public Pair(String x, String y) {
        this.x = x;
        this.y = y;
    }
}
